from django.conf.urls import url
from myapi.views import ApiDetailView

urlpatterns = [
    url(r'^api/(?P<pk>\S+)/$', ApiDetailView.as_view(), name='api_page'),
]