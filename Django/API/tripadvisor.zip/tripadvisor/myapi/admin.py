from django.contrib import admin
from myapi.models import Informasi

admin.site.register(Informasi)