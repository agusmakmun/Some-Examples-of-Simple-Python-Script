import json
import requests
from django.views import generic
from myapi.models import Informasi

class ApiDetailView(generic.DetailView):
    template_name = 'myapi/api_detail.html'
    model = Informasi

    def api_view(self):
        requests.packages.urllib3.disable_warnings()
        url  = 'http://api.tripadvisor.com/api/partner/2.0/location/89575?key=4c3f4e7957b444ce9ffa0d9b420fab8b'
        resp = requests.get(url=url)
        data = json.loads(resp.text)
        return data

    def get_context_data(self, **kwargs):
        context = super(ApiDetailView, self).get_context_data(**kwargs)
        context['data_json'] = self.api_view()
        return context